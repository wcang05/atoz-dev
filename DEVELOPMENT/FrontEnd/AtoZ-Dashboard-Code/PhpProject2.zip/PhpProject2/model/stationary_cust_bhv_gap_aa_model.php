<?php

class draw_stationary_cust_bhv_gap_aa{ 
    
    // For Bar Chart's table
    static function draw_chart_stationary_cust_bhv_gap_aa($year){
        
        // Draw bar chart (selected year)
        $bar_chart_query =   "SELECT metadata.Seg_Name AS segname, COUNT(*) AS head_count FROM google_chart_dev.s_cust_bhv_gap_aa
                                    INNER JOIN google_chart_dev.metadata ON s_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range
                                    AND s_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range
                                    WHERE s_cust_bhv_gap_aa.dataset_year=  '$year' 
                                    AND metadata.Conf_Name = 'cust_bhv_gap_aa'    
                                    GROUP BY metadata.Seg_Name
                                    ORDER BY head_count DESC
                                    ";  
        
        $bar_chart_result = mysqli_query(db_connect::connect(), $bar_chart_query);  
        
        while($result = mysqli_fetch_array($bar_chart_result))
            {
                $rows[]=array("c"=>array("0"=>array("v"=>$result['segname'],"f"=>NULL),
                                         "1"=>array("v"=>(int)$result['head_count'],"f" =>NULL)));
            }

        echo $format = '{
        "cols":
        [
        {"id":"","label":"Segment Name","pattern":"","type":"string"},
        {"id":"","label":"Head Count","pattern":"","type":"number"}
        ],
        "rows":'.json_encode($rows).'}';
    }
    
    // Generate table
    static function draw_table_stationary_cust_bhv_gap_aa($segname,$year){
        
        // Draw table (selected year and segment)
        $table_chart_update_query =   "SELECT s_cust_bhv_gap_aa.cust_id, 
                                        s_cust_bhv_gap_aa.firstname, 
                                        s_cust_bhv_gap_aa.lastname,
                                        s_cust_bhv_gap_aa.tel,
                                        s_cust_bhv_gap_aa.pcode , 
                                        s_cust_bhv_gap_aa.min_spt_gap , 
                                        s_cust_bhv_gap_aa.latest_manu, 
                                        s_cust_bhv_gap_aa.dataset_year 
                                   FROM google_chart_dev.s_cust_bhv_gap_aa
                                    INNER JOIN google_chart_dev.metadata 
                                    ON s_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                    AND s_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range     
                                    WHERE Seg_Name = '$segname' AND s_cust_bhv_gap_aa.dataset_year='$year' AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                    "; 
        $table_chart_update_result = mysqli_query(db_connect::connect(), $table_chart_update_query);  
        
        while($result = mysqli_fetch_array($table_chart_update_result)){
            $rows[]=array("c"=>array("0"=>array("v"=>$result['cust_id'],"f"=>NULL),
                                      "1"=>array("v"=>$result['firstname'],"f" =>NULL),
                                      "2"=>array("v"=>$result['lastname'],"f"=>NULL),
                                      "3"=>array("v"=>$result['tel'],"f"=>NULL),
                                      "4"=>array("v"=>$result['pcode'],"f" =>NULL),
                                      "5"=>array("v"=>(double)$result['min_spt_gap'],"f"=>NULL),
                                      "6"=>array("v"=>$result['latest_manu'],"f"=>NULL),
                                      "7"=>array("v"=>$result['dataset_year'],"f"=>NULL)));
            }

        echo $format = '{
            "cols":
            [
            {"id":"","label":"cust_id","pattern":"","type":"string"},
            {"id":"","label":"firstname","pattern":"","type":"string"},
            {"id":"","label":"lastname","pattern":"","type":"string"},
            {"id":"","label":"tel","pattern":"","type":"string"},
            {"id":"","label":"pcode","pattern":"","type":"string"},
            {"id":"","label":"min_spt_gap","pattern":"","type":"number"},
            {"id":"","label":"latest_manu","pattern":"","type":"string"},
            {"id":"","label":"dataset_year","pattern":"","type":"string"}
            ],
            "rows":'.json_encode($rows).'}'; 
    }
    
    static function draw_table_by_year_stationary_cust_bhv_gap_aa($year){
        
        // Draw table (largest area and laetst year)
        $default_table_query = "SELECT s_cust_bhv_gap_aa.cust_id, 
                                        s_cust_bhv_gap_aa.firstname, 
                                        s_cust_bhv_gap_aa.lastname,
                                        s_cust_bhv_gap_aa.tel,
                                        s_cust_bhv_gap_aa.pcode , 
                                        s_cust_bhv_gap_aa.min_spt_gap , 
                                        s_cust_bhv_gap_aa.latest_manu, 
                                        s_cust_bhv_gap_aa.dataset_year 
                                   from google_chart_dev.s_cust_bhv_gap_aa
                                   INNER JOIN google_chart_dev.metadata 
                                   ON s_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                   AND s_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                   WHERE Seg_Name = (
                                       SELECT segname 
                                       FROM (
                                           SELECT metadata.Seg_Name AS segname, COUNT(*) AS head_count 
                                           FROM google_chart_dev.s_cust_bhv_gap_aa
                                           INNER JOIN google_chart_dev.metadata 
                                           ON s_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range
                                           AND s_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range
                                           WHERE s_cust_bhv_gap_aa.dataset_year= (
                                               SELECT MAX(s_cust_bhv_gap_aa.dataset_year) AS year FROM google_chart_dev.s_cust_bhv_gap_aa
                                               )
                                            AND metadata.Conf_Name = 'cust_bhv_gap_aa'   
                                            GROUP BY metadata.Seg_Name
                                            ORDER BY head_count DESC LIMIT 1) AS x) 
                                   AND metadata.Conf_Name = 'cust_bhv_gap_aa'    
                                   AND s_cust_bhv_gap_aa.dataset_year='$year'";

        $default_table_result = mysqli_query(db_connect::connect(), $default_table_query);  
        
        while($result = mysqli_fetch_array($default_table_result)){
            $rows[]=array("c"=>array("0"=>array("v"=>$result['cust_id'],"f"=>NULL),
                                      "1"=>array("v"=>$result['firstname'],"f" =>NULL),
                                      "2"=>array("v"=>$result['lastname'],"f"=>NULL),
                                      "3"=>array("v"=>$result['tel'],"f"=>NULL),
                                      "4"=>array("v"=>(double)$result['pcode'],"f" =>NULL),
                                      "5"=>array("v"=>(double)$result['min_spt_gap'],"f"=>NULL),
                                      "6"=>array("v"=>(double)$result['latest_manu'],"f"=>NULL),
                                      "7"=>array("v"=>(double)$result['dataset_year'],"f" =>NULL)));
            }

        echo $format = '{
            "cols":
            [
            {"id":"","label":"cust_id","pattern":"","type":"string"},
            {"id":"","label":"firstname","pattern":"","type":"string"},
            {"id":"","label":"lastname","pattern":"","type":"string"},
            {"id":"","label":"tel","pattern":"","type":"string"},
            {"id":"","label":"pcode","pattern":"","type":"string"},
            {"id":"","label":"min_spt_gap","pattern":"","type":"number"},
            {"id":"","label":"latest_manu","pattern":"","type":"string"},
            {"id":"","label":"dataset_year","pattern":"","type":"string"}
            ],
            "rows":'.json_encode($rows).'}'; 
    }
    
}

