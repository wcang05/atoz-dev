<?php

class default_param_toner_cust_bhv_gap_aa {  
    
    // For bar Chart
    // Generate an array of years, from earliest until latest
    static function list_year_toner_cust_bhv_gap_aa(){
        
        $gen_year = "SELECT DISTINCT(dataset_year) AS year FROM google_chart_dev.t_cust_bhv_gap_aa ORDER BY year ASC";  
        $gen_year_result = mysqli_query(db_connect::connect(), $gen_year);  
        
        while($rows = mysqli_fetch_array($gen_year_result))
        {
          echo "<option value='".$rows['year']."'>".$rows['year']."</option>";
        }   
    }   
    
    // Generate latest year
    static function latest_year_toner_cust_bhv_gap_aa(){
        $latest_year_query = "SELECT MAX(t_cust_bhv_gap_aa.dataset_year) AS year FROM google_chart_dev.t_cust_bhv_gap_aa";
        $gen_latest_year_result = mysqli_query(db_connect::connect(), $latest_year_query);  
        
        while($rows = mysqli_fetch_array($gen_latest_year_result))
        {
          echo "value = '".$rows['year']."'";
        }   
    } 
    
    // Generate largest segment of bar chart
    static function largest_segment_toner_cust_bhv_gap_aa(){  
        // Generate the results of segment with the largest area
        $default_seg_query = "SELECT segname FROM (SELECT metadata.Seg_Name AS segname, COUNT(*) AS head_count 
                            FROM google_chart_dev.t_cust_bhv_gap_aa
                            INNER JOIN google_chart_dev.metadata 
                            ON t_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range
                            AND t_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range
                            WHERE t_cust_bhv_gap_aa.dataset_year= (
                            SELECT MAX(t_cust_bhv_gap_aa.dataset_year) AS year FROM google_chart_dev.t_cust_bhv_gap_aa
                            )
                            AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                            GROUP BY metadata.Seg_Name
                            ORDER BY head_count DESC LIMIT 1) AS x
                                                    ";
        $default_seg_result = mysqli_query(db_connect::connect(), $default_seg_query);  
        
        while($rows = mysqli_fetch_array($default_seg_result))
        {
          echo "value = '".$rows['segname']."'";
        }   
    }
}  

// Class to draw default chart
class default_bar_toner_cust_bhv_gap_aa{
    
    static function default_bar_chart_toner_cust_bhv_gap_aa(){
        
        // For bar Chart
        // Generate an array of segment name against their head counts. ()Latest year
        $default_barchart_query = "SELECT metadata.Seg_Name AS segname, COUNT(*) AS head_count 
                                    FROM google_chart_dev.t_cust_bhv_gap_aa
                                    INNER JOIN google_chart_dev.metadata ON t_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range
                                    AND t_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range
                                    WHERE t_cust_bhv_gap_aa.dataset_year= (SELECT MAX(t_cust_bhv_gap_aa.dataset_year) FROM google_chart_dev.t_cust_bhv_gap_aa)
                                    AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                    GROUP BY metadata.Seg_Name
                                    ORDER BY head_count DESC
                                    ";
        
        $default_barchart_result = mysqli_query(db_connect::connect(), $default_barchart_query);  
        
        while($row = mysqli_fetch_array($default_barchart_result))
        {
            echo "[`".$row["segname"]."`, ".$row["head_count"]."],";  
        } 
    }
    
    static function default_table_toner_cust_bhv_gap_aa(){
        // Draw table (largest area and latest year)
        $default_bar_table_query = "SELECT t_cust_bhv_gap_aa.cust_id, 
                                   t_cust_bhv_gap_aa.firstname, 
                                   t_cust_bhv_gap_aa.lastname,
                                   t_cust_bhv_gap_aa.tel,
                                   t_cust_bhv_gap_aa.pcode , 
                                   t_cust_bhv_gap_aa.min_spt_gap , 
                                   t_cust_bhv_gap_aa.latest_manu, 
                                   t_cust_bhv_gap_aa.dataset_year 
                                   FROM google_chart_dev.t_cust_bhv_gap_aa
                                   INNER JOIN google_chart_dev.metadata 
                                   ON t_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                   AND t_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                   WHERE Seg_Name = (
                                       SELECT segname 
                                       FROM (
                                           SELECT metadata.Seg_Name AS segname, COUNT(*) AS head_count 
                                           FROM google_chart_dev.t_cust_bhv_gap_aa
                                           INNER JOIN google_chart_dev.metadata 
                                           ON t_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range
                                           AND t_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range
                                           WHERE t_cust_bhv_gap_aa.dataset_year= (
                                               SELECT MAX(t_cust_bhv_gap_aa.dataset_year) AS year FROM google_chart_dev.t_cust_bhv_gap_aa)
                                               AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                               GROUP BY metadata.Seg_Name
                                               ORDER BY head_count DESC LIMIT 1) AS x) 
                                   AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                   AND t_cust_bhv_gap_aa.dataset_year=(
                                       SELECT MAX(t_cust_bhv_gap_aa.dataset_year) AS year FROM google_chart_dev.t_cust_bhv_gap_aa)
                                           ";
        $default_bar_table_result = mysqli_query(db_connect::connect(), $default_bar_table_query);  
        
        while($row = mysqli_fetch_array($default_bar_table_result)){  
                    // echo "['".$row["segname"]."', ".$row["head_count"]."],";  
                    echo '[`'.$row["cust_id"].'`, `'.$row["firstname"].'`, "'.$row["lastname"].'", `'.$row["tel"]."`, `".$row["pcode"]."`, ".$row["min_spt_gap"].", `".$row["latest_manu"]."`, `".$row["dataset_year"]."`],";  
                } 
    }
}

