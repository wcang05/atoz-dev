<?php

class data{
    
    static function export_all_cust_bhv_gap_aa($segname, $year){
        header('Content-Type: text/csv; charset=utf-8');  
       
        // Content-Disposition: Force download using browser
        // Suggest user new file name before download
        header('Content-Disposition: attachment; filename=data.csv');  

        // Write file
        $output = fopen("php://output", "w");  

        // SQL query
        $table_chart_update_query =   "SELECT all_cust_bhv_gap_aa.cust_id, 
                                            all_cust_bhv_gap_aa.firstname, 
                                            all_cust_bhv_gap_aa.lastname, 
                                            all_cust_bhv_gap_aa.tel, 
                                            all_cust_bhv_gap_aa.pcode, 
                                            all_cust_bhv_gap_aa.min_spt_gap, 
                                            all_cust_bhv_gap_aa.latest_manu,
                                            all_cust_bhv_gap_aa.dataset_year 
                                 FROM google_chart_dev.all_cust_bhv_gap_aa
                                 INNER JOIN google_chart_dev.metadata 
                                 ON all_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                 AND all_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                 WHERE Seg_Name = '$segname' AND all_cust_bhv_gap_aa.dataset_year='$year' AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                 ";  

        // Define column name
        fputcsv($output, array('cust_id', 'firstname', 'lastname', 'tel', 'pcode', 'min_spt_gap', 'latest_manu', 'dataset_year'));  
        $table_chart_update_result = mysqli_query(db_connect::connect(), $table_chart_update_query);  
        while($row = mysqli_fetch_assoc($table_chart_update_result))  
        {  
             fputcsv($output, $row);  
        }  
        fclose($output);  
    }
    
    static function export_ink_cust_bhv_gap_aa($segname, $year){
        header('Content-Type: text/csv; charset=utf-8');  
       
        // Content-Disposition: Force download using browser
        // Suggest user new file name before download
        header('Content-Disposition: attachment; filename=data.csv');  

        // Write file
        $output = fopen("php://output", "w");  

        // SQL query
        $table_chart_update_query =   "SELECT i_cust_bhv_gap_aa.cust_id, 
                                            i_cust_bhv_gap_aa.firstname, 
                                            i_cust_bhv_gap_aa.lastname, 
                                            i_cust_bhv_gap_aa.tel, 
                                            i_cust_bhv_gap_aa.pcode, 
                                            i_cust_bhv_gap_aa.min_spt_gap, 
                                            i_cust_bhv_gap_aa.latest_manu,
                                            i_cust_bhv_gap_aa.dataset_year 
                                 FROM google_chart_dev.i_cust_bhv_gap_aa
                                 INNER JOIN google_chart_dev.metadata 
                                 ON i_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                 AND i_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                 WHERE Seg_Name = '$segname' AND i_cust_bhv_gap_aa.dataset_year='$year' AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                 ";  

        // Define column name
        fputcsv($output, array('cust_id', 'firstname', 'lastname', 'tel', 'pcode', 'min_spt_gap', 'latest_manu', 'dataset_year'));  
        $table_chart_update_result = mysqli_query(db_connect::connect(), $table_chart_update_query);  
        while($row = mysqli_fetch_assoc($table_chart_update_result))  
        {  
             fputcsv($output, $row);  
        }  
        fclose($output);  
    }
    
    static function export_toner_cust_bhv_gap_aa($segname, $year){
        header('Content-Type: text/csv; charset=utf-8');  
       
        // Content-Disposition: Force download using browser
        // Suggest user new file name before download
        header('Content-Disposition: attachment; filename=data.csv');  

        // Write file
        $output = fopen("php://output", "w");  

        // SQL query
        $table_chart_update_query =   "SELECT t_cust_bhv_gap_aa.cust_id, 
                                            t_cust_bhv_gap_aa.firstname, 
                                            t_cust_bhv_gap_aa.lastname, 
                                            t_cust_bhv_gap_aa.tel, 
                                            t_cust_bhv_gap_aa.pcode, 
                                            t_cust_bhv_gap_aa.min_spt_gap, 
                                            t_cust_bhv_gap_aa.latest_manu,
                                            t_cust_bhv_gap_aa.dataset_year 
                                 FROM google_chart_dev.t_cust_bhv_gap_aa
                                 INNER JOIN google_chart_dev.metadata 
                                 ON t_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                 AND t_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                 WHERE Seg_Name = '$segname' AND t_cust_bhv_gap_aa.dataset_year='$year' AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                 ";  

        // Define column name
        fputcsv($output, array('cust_id', 'firstname', 'lastname', 'tel', 'pcode', 'min_spt_gap', 'latest_manu', 'dataset_year'));  
        $table_chart_update_result = mysqli_query(db_connect::connect(), $table_chart_update_query);  
        while($row = mysqli_fetch_assoc($table_chart_update_result))  
        {  
             fputcsv($output, $row);  
        }  
        fclose($output);  
    }
    
    static function export_printer_cust_bhv_gap_aa($segname, $year){
        header('Content-Type: text/csv; charset=utf-8');  
       
        // Content-Disposition: Force download using browser
        // Suggest user new file name before download
        header('Content-Disposition: attachment; filename=data.csv');  

        // Write file
        $output = fopen("php://output", "w");  

        // SQL query
        $table_chart_update_query =   "SELECT p_cust_bhv_gap_aa.cust_id, 
                                            p_cust_bhv_gap_aa.firstname, 
                                            p_cust_bhv_gap_aa.lastname, 
                                            p_cust_bhv_gap_aa.tel, 
                                            p_cust_bhv_gap_aa.pcode, 
                                            p_cust_bhv_gap_aa.min_spt_gap, 
                                            p_cust_bhv_gap_aa.latest_manu,
                                            p_cust_bhv_gap_aa.dataset_year 
                                 FROM google_chart_dev.p_cust_bhv_gap_aa
                                 INNER JOIN google_chart_dev.metadata 
                                 ON p_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                 AND p_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                 WHERE Seg_Name = '$segname' AND p_cust_bhv_gap_aa.dataset_year='$year' AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                 ";  

        // Define column name
        fputcsv($output, array('cust_id', 'firstname', 'lastname', 'tel', 'pcode', 'min_spt_gap', 'latest_manu', 'dataset_year'));  
        $table_chart_update_result = mysqli_query(db_connect::connect(), $table_chart_update_query);  
        while($row = mysqli_fetch_assoc($table_chart_update_result))  
        {  
             fputcsv($output, $row);  
        }  
        fclose($output);  
    }
    
    static function export_paper_cust_bhv_gap_aa($segname, $year){
        header('Content-Type: text/csv; charset=utf-8');  
       
        // Content-Disposition: Force download using browser
        // Suggest user new file name before download
        header('Content-Disposition: attachment; filename=data.csv');  

        // Write file
        $output = fopen("php://output", "w");  

        // SQL query
        $table_chart_update_query =   "SELECT pa_cust_bhv_gap_aa.cust_id, 
                                            pa_cust_bhv_gap_aa.firstname, 
                                            pa_cust_bhv_gap_aa.lastname, 
                                            pa_cust_bhv_gap_aa.tel, 
                                            pa_cust_bhv_gap_aa.pcode, 
                                            pa_cust_bhv_gap_aa.min_spt_gap, 
                                            pa_cust_bhv_gap_aa.latest_manu,
                                            pa_cust_bhv_gap_aa.dataset_year 
                                 FROM google_chart_dev.pa_cust_bhv_gap_aa
                                 INNER JOIN google_chart_dev.metadata 
                                 ON pa_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                 AND pa_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                 WHERE Seg_Name = '$segname' AND pa_cust_bhv_gap_aa.dataset_year='$year' AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                 ";  

        // Define column name
        fputcsv($output, array('cust_id', 'firstname', 'lastname', 'tel', 'pcode', 'min_spt_gap', 'latest_manu', 'dataset_year'));  
        $table_chart_update_result = mysqli_query(db_connect::connect(), $table_chart_update_query);  
        while($row = mysqli_fetch_assoc($table_chart_update_result))  
        {  
             fputcsv($output, $row);  
        }  
        fclose($output);  
    }
    
    static function export_stationary_cust_bhv_gap_aa($segname, $year){
        header('Content-Type: text/csv; charset=utf-8');  
       
        // Content-Disposition: Force download using browser
        // Suggest user new file name before download
        header('Content-Disposition: attachment; filename=data.csv');  

        // Write file
        $output = fopen("php://output", "w");  

        // SQL query
        $table_chart_update_query =   "SELECT s_cust_bhv_gap_aa.cust_id, 
                                            s_cust_bhv_gap_aa.firstname, 
                                            s_cust_bhv_gap_aa.lastname, 
                                            s_cust_bhv_gap_aa.tel, 
                                            s_cust_bhv_gap_aa.pcode, 
                                            s_cust_bhv_gap_aa.min_spt_gap, 
                                            s_cust_bhv_gap_aa.latest_manu,
                                            s_cust_bhv_gap_aa.dataset_year 
                                 FROM google_chart_dev.s_cust_bhv_gap_aa
                                 INNER JOIN google_chart_dev.metadata 
                                 ON s_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                 AND s_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                 WHERE Seg_Name = '$segname' AND s_cust_bhv_gap_aa.dataset_year='$year' AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                 ";  

        // Define column name
        fputcsv($output, array('cust_id', 'firstname', 'lastname', 'tel', 'pcode', 'min_spt_gap', 'latest_manu', 'dataset_year'));  
        $table_chart_update_result = mysqli_query(db_connect::connect(), $table_chart_update_query);  
        while($row = mysqli_fetch_assoc($table_chart_update_result))  
        {  
             fputcsv($output, $row);  
        }  
        fclose($output);  
    }
    
    static function export_clean_cust_bhv_gap_aa($segname, $year){
        header('Content-Type: text/csv; charset=utf-8');  
       
        // Content-Disposition: Force download using browser
        // Suggest user new file name before download
        header('Content-Disposition: attachment; filename=data.csv');  

        // Write file
        $output = fopen("php://output", "w");  

        // SQL query
        $table_chart_update_query =   "SELECT c_cust_bhv_gap_aa.cust_id, 
                                            c_cust_bhv_gap_aa.firstname, 
                                            c_cust_bhv_gap_aa.lastname, 
                                            c_cust_bhv_gap_aa.tel, 
                                            c_cust_bhv_gap_aa.pcode, 
                                            c_cust_bhv_gap_aa.min_spt_gap, 
                                            c_cust_bhv_gap_aa.latest_manu,
                                            c_cust_bhv_gap_aa.dataset_year 
                                 FROM google_chart_dev.c_cust_bhv_gap_aa
                                 INNER JOIN google_chart_dev.metadata 
                                 ON c_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                 AND c_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                 WHERE Seg_Name = '$segname' AND c_cust_bhv_gap_aa.dataset_year='$year' AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                 ";  

        // Define column name
        fputcsv($output, array('cust_id', 'firstname', 'lastname', 'tel', 'pcode', 'min_spt_gap', 'latest_manu', 'dataset_year'));  
        $table_chart_update_result = mysqli_query(db_connect::connect(), $table_chart_update_query);  
        while($row = mysqli_fetch_assoc($table_chart_update_result))  
        {  
             fputcsv($output, $row);  
        }  
        fclose($output);  
    }
    
    static function export_brk_cust_bhv_gap_aa($segname, $year){
        header('Content-Type: text/csv; charset=utf-8');  
       
        // Content-Disposition: Force download using browser
        // Suggest user new file name before download
        header('Content-Disposition: attachment; filename=data.csv');  

        // Write file
        $output = fopen("php://output", "w");  

        // SQL query
        $table_chart_update_query =   "SELECT b_cust_bhv_gap_aa.cust_id, 
                                            b_cust_bhv_gap_aa.firstname, 
                                            b_cust_bhv_gap_aa.lastname, 
                                            b_cust_bhv_gap_aa.tel, 
                                            b_cust_bhv_gap_aa.pcode, 
                                            b_cust_bhv_gap_aa.min_spt_gap, 
                                            b_cust_bhv_gap_aa.latest_manu,
                                            b_cust_bhv_gap_aa.dataset_year 
                                 FROM google_chart_dev.b_cust_bhv_gap_aa
                                 INNER JOIN google_chart_dev.metadata 
                                 ON b_cust_bhv_gap_aa.min_spt_gap >= metadata.Low_Range 
                                 AND b_cust_bhv_gap_aa.min_spt_gap < metadata.High_Range 
                                 WHERE Seg_Name = '$segname' AND b_cust_bhv_gap_aa.dataset_year='$year' AND metadata.Conf_Name = 'cust_bhv_gap_aa'
                                 ";  

        // Define column name
        fputcsv($output, array('cust_id', 'firstname', 'lastname', 'tel', 'pcode', 'min_spt_gap', 'latest_manu', 'dataset_year'));  
        $table_chart_update_result = mysqli_query(db_connect::connect(), $table_chart_update_query);  
        while($row = mysqli_fetch_assoc($table_chart_update_result))  
        {  
             fputcsv($output, $row);  
        }  
        fclose($output);  
    }
}

