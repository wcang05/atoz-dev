<?php
include_once("../control/def_control_all_cust_bhv_gap_aa.php");  
$default_control_all_cust_bhv_gap_aa = new default_control_all_cust_bhv_gap_aa();  

include_once("../control/def_control_ink_cust_bhv_gap_aa.php");  
$default_control_ink_cust_bhv_gap_aa = new default_control_ink_cust_bhv_gap_aa();  

include_once("../control/def_control_toner_cust_bhv_gap_aa.php");  
$default_control_toner_cust_bhv_gap_aa = new default_control_toner_cust_bhv_gap_aa();  

include_once("../control/def_control_printer_cust_bhv_gap_aa.php");  
$default_control_printer_cust_bhv_gap_aa = new default_control_printer_cust_bhv_gap_aa(); 

include_once("../control/def_control_paper_cust_bhv_gap_aa.php");  
$default_control_paper_cust_bhv_gap_aa = new default_control_paper_cust_bhv_gap_aa();  

include_once("../control/def_control_stationary_cust_bhv_gap_aa.php");  
$default_control_stationary_cust_bhv_gap_aa = new default_control_stationary_cust_bhv_gap_aa();  

include_once("../control/def_control_clean_cust_bhv_gap_aa.php");  
$default_control_clean_cust_bhv_gap_aa = new default_control_clean_cust_bhv_gap_aa();  

include_once("../control/def_control_brk_cust_bhv_gap_aa.php");  
$default_control_brk_cust_bhv_gap_aa = new default_control_brk_cust_bhv_gap_aa();  
?>

<html>
    <head>
        <title>Dashboard 1</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/cust_bhv_gap_aa.css"/>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript" src="../view/default_all_cust_bhv_gap_aa.js.php"></script>
        <script type="text/javascript" src="../view/draw_all_cust_bhv_gap_aa.js"></script>
        <script type="text/javascript" src="../view/default_ink_cust_bhv_gap_aa.js.php"></script>
        <script type="text/javascript" src="../view/draw_ink_cust_bhv_gap_aa.js"></script>
        <script type="text/javascript" src="../view/default_toner_cust_bhv_gap_aa.js.php"></script>
        <script type="text/javascript" src="../view/draw_toner_cust_bhv_gap_aa.js"></script>
        <script type="text/javascript" src="../view/default_printer_cust_bhv_gap_aa.js.php"></script>
        <script type="text/javascript" src="../view/draw_printer_cust_bhv_gap_aa.js"></script>
        <script type="text/javascript" src="../view/default_paper_cust_bhv_gap_aa.js.php"></script>
        <script type="text/javascript" src="../view/draw_paper_cust_bhv_gap_aa.js"></script>
        <script type="text/javascript" src="../view/default_stationary_cust_bhv_gap_aa.js.php"></script>
        <script type="text/javascript" src="../view/draw_stationary_cust_bhv_gap_aa.js"></script>
        <script type="text/javascript" src="../view/default_clean_cust_bhv_gap_aa.js.php"></script>
        <script type="text/javascript" src="../view/draw_clean_cust_bhv_gap_aa.js"></script>
        <script type="text/javascript" src="../view/default_brk_cust_bhv_gap_aa.js.php"></script>
        <script type="text/javascript" src="../view/draw_brk_cust_bhv_gap_aa.js"></script>
        <script>
            google.charts.load('current', {'packages':['corechart']});  
            google.charts.load('current', {'packages':['table']});
            google.charts.setOnLoadCallback(default_all_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_table_all_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_ink_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_table_ink_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_toner_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_table_toner_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_printer_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_table_printer_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_paper_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_table_paper_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_stationary_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_table_stationary_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_clean_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_table_clean_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_brk_cust_bhv_gap_aa);
            google.charts.setOnLoadCallback(default_table_brk_cust_bhv_gap_aa);
        </script>
    </head>
    <body>
        <!---   
        
        Bar All Charts
        
        --->
        <div id="current_all_segment_div">
            <p>Selected Segment:</p>
            <p id="current_all_segment"></p>
        </div>
        <div id="year_selector_all_bar">
            Year:   <select name="bar_all_year">
                        <option value="">Choose year</option>
                        <?php $default_control_all_cust_bhv_gap_aa->list_year_all_cust_bhv_gap_aa();?>   
                    </select>
        </div>
        <div id="year_select_all_bar_apply">    
            <button onclick="all_cust_bhv_gap_aa_chart();all_cust_bhv_gap_aa_table();">Apply</button>
        </div>    
        <div id="bar_all_chart"></div>
        <div id="table_all_chart"></div>
        <div id="bar_all_data_export">
            <form action="../control/export_controller.php" method="POST">
                <input type="hidden" id="year_all_bar" name="year_all_bar" <?php $default_control_all_cust_bhv_gap_aa->latest_year_all_cust_bhv_gap_aa();?>/>
                <input type="hidden" id="segment_all_bar" name="segment_all_bar" <?php $default_control_all_cust_bhv_gap_aa->largest_segment_all_cust_bhv_gap_aa();?>/>
                <input type="hidden" name="table" value="all_cust_bhv_gap_aa">
                <input type="submit" name="export" value="CSV Export">
            </form>    
        </div>  
        
        <!---   
        
        Bar Ink Charts
        
        --->
        <div id="current_ink_segment_div">
            <p>Selected Segment:</p>
            <p id="current_ink_segment"></p>
        </div>
        <div id="year_selector_ink_bar">
            Year:   <select name="bar_ink_year">
                        <option value="">Choose year</option> 
                        <?php $default_control_ink_cust_bhv_gap_aa->list_year_ink_cust_bhv_gap_aa();?>  
                    </select>
        </div>
        <div id="year_select_ink_bar_apply">    
            <button onclick="ink_cust_bhv_gap_aa_chart();ink_cust_bhv_gap_aa_table();">Apply</button>
        </div>    
        <div id="bar_ink_chart"></div>
        <div id="table_ink_chart"></div>
        <div id="bar_ink_data_export">
            <form action="../control/export_controller.php" method="POST">
                <input type="hidden" id="year_ink_bar" name="year_ink_bar" <?php $default_control_ink_cust_bhv_gap_aa->latest_year_ink_cust_bhv_gap_aa();?>/>
                <input type="hidden" id="segment_ink_bar" name="segment_ink_bar" <?php $default_control_ink_cust_bhv_gap_aa->largest_segment_ink_cust_bhv_gap_aa();?>/>
                <input type="hidden" name="table" value="ink_cust_bhv_gap_aa">
                <input type="submit" name="export" value="CSV Export">
            </form>    
        </div>  
        
        <!---   
        
        Bar Toner Charts
        
        --->
        <div id="current_toner_segment_div">
            <p>Selected Segment:</p>
            <p id="current_toner_segment"></p>
        </div>
        <div id="year_selector_toner_bar">
            Year:   <select name="bar_toner_year">
                        <option value="">Choose year</option> 
                        <?php $default_control_toner_cust_bhv_gap_aa->list_year_toner_cust_bhv_gap_aa();?>  
                    </select>
        </div>
        <div id="year_select_toner_bar_apply">    
            <button onclick="toner_cust_bhv_gap_aa_chart();toner_cust_bhv_gap_aa_table();">Apply</button>
        </div>    
        <div id="bar_toner_chart"></div>
        <div id="table_toner_chart"></div>
        <div id="bar_toner_data_export">
            <form action="../control/export_controller.php" method="POST">
                <input type="hidden" id="year_toner_bar" name="year_toner_bar" <?php $default_control_toner_cust_bhv_gap_aa->latest_year_toner_cust_bhv_gap_aa();?>/>
                <input type="hidden" id="segment_toner_bar" name="segment_toner_bar" <?php $default_control_toner_cust_bhv_gap_aa->largest_segment_toner_cust_bhv_gap_aa();?>/>
                <input type="hidden" name="table" value="toner_cust_bhv_gap_aa">
                <input type="submit" name="export" value="CSV Export">
            </form>    
        </div>  
        
        <!---   
        
        Bar printer Charts
        
        --->
        <div id="current_printer_segment_div">
            <p>Selected Segment:</p>
            <p id="current_printer_segment"></p>
        </div>
        <div id="year_selector_printer_bar">
            Year:   <select name="bar_printer_year">
                        <option value="">Choose year</option>
                        <?php $default_control_printer_cust_bhv_gap_aa->list_year_printer_cust_bhv_gap_aa();?>   
                    </select>
        </div>
        <div id="year_select_printer_bar_apply">    
            <button onclick="printer_cust_bhv_gap_aa_chart();printer_cust_bhv_gap_aa_table();">Apply</button>
        </div>    
        <div id="bar_printer_chart"></div>
        <div id="table_printer_chart"></div>
        <div id="bar_printer_data_export">
            <form action="../control/export_controller.php" method="POST">
                <input type="hidden" id="year_printer_bar" name="year_printer_bar" <?php $default_control_printer_cust_bhv_gap_aa->latest_year_printer_cust_bhv_gap_aa();?>/>
                <input type="hidden" id="segment_printer_bar" name="segment_printer_bar" <?php $default_control_printer_cust_bhv_gap_aa->largest_segment_printer_cust_bhv_gap_aa();?>/>
                <input type="hidden" name="table" value="printer_cust_bhv_gap_aa">
                <input type="submit" name="export" value="CSV Export">
            </form>    
        </div>  
        <!---   
        
        Bar Paper Charts
        
        --->
        <div id="current_paper_segment_div">
            <p>Selected Segment:</p>
            <p id="current_paper_segment"></p>
        </div>
        <div id="year_selector_paper_bar">
            Year:   <select name="bar_paper_year">
                        <option value="">Choose year</option>
                        <?php $default_control_paper_cust_bhv_gap_aa->list_year_paper_cust_bhv_gap_aa();?>   
                    </select>
        </div>
        <div id="year_select_paper_bar_apply">    
            <button onclick="paper_cust_bhv_gap_aa_chart();paper_cust_bhv_gap_aa_table();">Apply</button>
        </div>    
        <div id="bar_paper_chart"></div>
        <div id="table_paper_chart"></div>
        <div id="bar_paper_data_export">
            <form action="../control/export_controller.php" method="POST">
                <input type="hidden" id="year_paper_bar" name="year_paper_bar" <?php $default_control_paper_cust_bhv_gap_aa->latest_year_paper_cust_bhv_gap_aa();?>/>
                <input type="hidden" id="segment_paper_bar" name="segment_paper_bar" <?php $default_control_paper_cust_bhv_gap_aa->largest_segment_paper_cust_bhv_gap_aa();?>/>
                <input type="hidden" name="table" value="paper_cust_bhv_gap_aa">
                <input type="submit" name="export" value="CSV Export">
            </form>    
        </div>  
        <!---   
        
        Bar stationary Charts
        
        --->
        <div id="current_stationary_segment_div">
            <p>Selected Segment:</p>
            <p id="current_stationary_segment"></p>
        </div>
        <div id="year_selector_stationary_bar">
            Year:   <select name="bar_stationary_year">
                        <option value="">Choose year</option>
                        <?php $default_control_stationary_cust_bhv_gap_aa->list_year_stationary_cust_bhv_gap_aa();?>   
                    </select>
        </div>
        <div id="year_select_stationary_bar_apply">    
            <button onclick="stationary_cust_bhv_gap_aa_chart();stationary_cust_bhv_gap_aa_table();">Apply</button>
        </div>    
        <div id="bar_stationary_chart"></div>
        <div id="table_stationary_chart"></div>
        <div id="bar_stationary_data_export">
            <form action="../control/export_controller.php" method="POST">
                <input type="hidden" id="year_stationary_bar" name="year_stationary_bar" <?php $default_control_stationary_cust_bhv_gap_aa->latest_year_stationary_cust_bhv_gap_aa();?>/>
                <input type="hidden" id="segment_stationary_bar" name="segment_stationary_bar" <?php $default_control_stationary_cust_bhv_gap_aa->largest_segment_stationary_cust_bhv_gap_aa();?>/>
                <input type="hidden" name="table" value="stationary_cust_bhv_gap_aa">
                <input type="submit" name="export" value="CSV Export">
            </form>    
        </div>  
        <!---   
        
        Bar clean Charts
        
        --->
        <div id="current_clean_segment_div">
            <p>Selected Segment:</p>
            <p id="current_clean_segment"></p>
        </div>
        <div id="year_selector_clean_bar">
            Year:   <select name="bar_clean_year">
                        <option value="">Choose year</option>
                        <?php $default_control_clean_cust_bhv_gap_aa->list_year_clean_cust_bhv_gap_aa();?>   
                    </select>
        </div>
        <div id="year_select_clean_bar_apply">    
            <button onclick="clean_cust_bhv_gap_aa_chart();clean_cust_bhv_gap_aa_table();">Apply</button>
        </div>    
        <div id="bar_clean_chart"></div>
        <div id="table_clean_chart"></div>
        <div id="bar_clean_data_export">
            <form action="../control/export_controller.php" method="POST">
                <input type="hidden" id="year_clean_bar" name="year_clean_bar" <?php $default_control_clean_cust_bhv_gap_aa->latest_year_clean_cust_bhv_gap_aa();?>/>
                <input type="hidden" id="segment_clean_bar" name="segment_clean_bar" <?php $default_control_clean_cust_bhv_gap_aa->largest_segment_clean_cust_bhv_gap_aa();?>/>
                <input type="hidden" name="table" value="clean_cust_bhv_gap_aa">
                <input type="submit" name="export" value="CSV Export">
            </form>    
        </div>  
        <!---   
        
        Bar Break Room Charts
        
        --->
        <div id="current_brk_segment_div">
            <p>Selected Segment:</p>
            <p id="current_brk_segment"></p>
        </div>
        <div id="year_selector_brk_bar">
            Year:   <select name="bar_brk_year">
                        <option value="">Choose year</option>
                        <?php $default_control_brk_cust_bhv_gap_aa->list_year_brk_cust_bhv_gap_aa();?>   
                    </select>
        </div>
        <div id="year_select_brk_bar_apply">    
            <button onclick="brk_cust_bhv_gap_aa_chart();brk_cust_bhv_gap_aa_table();">Apply</button>
        </div>    
        <div id="bar_brk_chart"></div>
        <div id="table_brk_chart"></div>
        <div id="bar_brk_data_export">
            <form action="../control/export_controller.php" method="POST">
                <input type="hidden" id="year_brk_bar" name="year_brk_bar" <?php $default_control_brk_cust_bhv_gap_aa->latest_year_brk_cust_bhv_gap_aa();?>/>
                <input type="hidden" id="segment_brk_bar" name="segment_brk_bar" <?php $default_control_brk_cust_bhv_gap_aa->largest_segment_brk_cust_bhv_gap_aa();?>/>
                <input type="hidden" name="table" value="brk_cust_bhv_gap_aa">
                <input type="submit" name="export" value="CSV Export">
            </form>    
        </div>  
    </body>    
</html>