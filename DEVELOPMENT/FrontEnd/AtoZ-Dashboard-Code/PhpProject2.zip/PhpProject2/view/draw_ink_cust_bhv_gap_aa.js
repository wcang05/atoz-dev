// Call function to draw google chart.
google.charts.load('current', {'packages':['corechart']});  
google.charts.setOnLoadCallback(ink_cust_bhv_gap_aa_chart);

function ink_cust_bhv_gap_aa_chart() {
    
    // Get the value for year
    var year = document.getElementsByName("bar_ink_year")[0].value;  
    
    var xhttp;    

    // If year is not define, do nothing.
    if (year == "") {
        return;
    } 
     
    // Launch new request to backend
    xhttp = new XMLHttpRequest();
    
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {    // If request finished and response is ready/ OK
        
        // Load the JSON data in the table
        var data = new google.visualization.DataTable(this.responseText);
        
        // Chart option
        var options = {
                    title: 'Customer Purchasing Gap Analysis for Ink Categories. Year Range: '+year,
                    height: 325,
                    width: 550
                    };

        // Instantiate and draw our chart, passing in some options.
        var bar_chart = new google.visualization.BarChart(document.getElementById('bar_ink_chart'));  
        bar_chart.draw(data, options);
        
        // Set the selected default bar chart segment
        bar_chart.setSelection([{row: 0}]); 
        var selected = bar_chart.getSelection()[0];
        var segment = data.getValue(selected.row, 0);
        if(segment == "15 Days"){
            document.getElementById("current_ink_segment_div").style.backgroundColor = "blue";
            document.getElementById("current_ink_segment_div").style.color = "white";
        }else if(segment == "30 Days"){
            document.getElementById("current_ink_segment_div").style.backgroundColor = "red";
            document.getElementById("current_ink_segment_div").style.color = "white";
        }else if(segment == "45 Days"){
            document.getElementById("current_ink_segment_div").style.backgroundColor = "orange";
            document.getElementById("current_ink_segment_div").style.color = "black";
        }else if(segment == "60 Days"){
            document.getElementById("current_ink_segment_div").style.backgroundColor = "green";
            document.getElementById("current_ink_segment_div").style.color = "white";
        }else if(segment == "75 Days"){
            document.getElementById("current_ink_segment_div").style.backgroundColor = "purple";
            document.getElementById("current_ink_segment_div").style.color = "white";
        }else if(segment == "90 Days"){
            document.getElementById("current_ink_segment_div").style.backgroundColor = "black";
            document.getElementById("current_ink_segment_div").style.color = "white";
        }else if(segment == "> 90 Days"){
            document.getElementById("current_ink_segment_div").style.backgroundColor = "pink";
            document.getElementById("current_ink_segment_div").style.color = "black";
        }
        
        // Print the selected segment name
        document.getElementById("current_ink_segment").innerHTML = segment;

        // Save the segment name in hidden input
        document.getElementById("segment_ink_bar").value = segment;

        // Save the selected year in hidden input
        document.getElementById("year_ink_bar").value = year;
        
        // Define function to generate table for selected segment
        function genTableBySeg() {
            
            var selectedItem = bar_chart.getSelection()[0];
            
            if (selectedItem) {
                // Get segment name
                var segname = data.getValue(selectedItem.row, 0);
                
                if(segname == "15 Days"){
                    document.getElementById("current_ink_segment_div").style.backgroundColor = "blue";
                    document.getElementById("current_ink_segment_div").style.color = "white";
                }else if(segname == "30 Days"){
                    document.getElementById("current_ink_segment_div").style.backgroundColor = "red";
                    document.getElementById("current_ink_segment_div").style.color = "white";
                }else if(segname == "45 Days"){
                    document.getElementById("current_ink_segment_div").style.backgroundColor = "orange";
                    document.getElementById("current_ink_segment_div").style.color = "black";
                }else if(segname == "60 Days"){
                    document.getElementById("current_ink_segment_div").style.backgroundColor = "green";
                    document.getElementById("current_ink_segment_div").style.color = "white";
                }else if(segname == "75 Days"){
                    document.getElementById("current_ink_segment_div").style.backgroundColor = "purple";
                    document.getElementById("current_ink_segment_div").style.color = "white";
                }else if(segname == "90 Days"){
                    document.getElementById("current_ink_segment_div").style.backgroundColor = "black";
                    document.getElementById("current_ink_segment_div").style.color = "white";
                }else if(segname == "> 90 Days"){
                    document.getElementById("current_ink_segment_div").style.backgroundColor = "pink";
                    document.getElementById("current_ink_segment_div").style.color = "black";
                }
   
                // Print the selected segment name
                document.getElementById("current_ink_segment").innerHTML = segname;
                
                // Save the segment name in hidden input
                document.getElementById("segment_ink_bar").value = segname;
                
                // Launch new request to backend
                xhttp = new XMLHttpRequest();
                
                xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {   // If request finished and response is ready/ OK
                    
                     // Load the JSON data in the table
                    var data = new google.visualization.DataTable(this.responseText);

                    // Instantiate and draw our chart, passing in some options.
                    var table = new google.visualization.Table(document.getElementById('table_ink_chart'));
                    table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
                    }
                }
                
                 // Forward parameters to PHP file
                xhttp.open("GET", "../control/draw_control_ink_cust_bhv_gap_aa.php?action=draw_table&year="+year+"&segname="+segname, true);
                xhttp.send();
            }
          }
          
        // Enable the bar chart's event listener after its segment being selected 
        google.visualization.events.addListener(bar_chart, 'select', genTableBySeg);
    }
  };
  
  // Forward parameters to PHP file
  xhttp.open("GET", "../control/draw_control_ink_cust_bhv_gap_aa.php?action=draw_bar_chart&year="+year, true);
  xhttp.send();
}

function ink_cust_bhv_gap_aa_table(){
    // Get the value for year
    var year = document.getElementsByName("bar_ink_year")[0].value;  
    
    if (year == "") {
        return;
    } 
    
    var xhttp;   
    
    // Launch new request to backend
    xhttp = new XMLHttpRequest();
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {    // If request finished and response is ready/ OK

            // Load the JSON data in the table
            var data = new google.visualization.DataTable(this.responseText);

            // Specify the container for chart drawing
            var default_table_by_year = new google.visualization.Table(document.getElementById('table_ink_chart'));
            default_table_by_year.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
            }
        }
        
         // Forward parameters to PHP file
        xhttp.open("GET", "../control/draw_control_ink_cust_bhv_gap_aa.php?action=draw_table_by_year&year="+year, true);
        xhttp.send();
    }   
    
   

