<?php
    header("Content-Type: application/javasctipt");
    include_once("../control/def_control_toner_cust_bhv_gap_aa.php");  
    $default_control_toner_cust_bhv_gap_aa = new default_control_toner_cust_bhv_gap_aa();  
?>
    function default_toner_cust_bhv_gap_aa(){  
        // Get the value for year
        var year = document.getElementById("year_toner_bar").value;
        
        // Get the segment name
        var segment_bar = document.getElementById("segment_toner_bar").value;

        var data = google.visualization.arrayToDataTable([  
            //Column name
            ['segname', 'head_count'],  

            //for loop to generate rows from pre-defiend SQL
            <?php $default_control_toner_cust_bhv_gap_aa->default_bar_toner_cust_bhv_gap_aa();?>
        ]);  
        var options = { 
              //bar chart title
              title: "Customer Purchasing Gap Analysis for Toner Categories. Year Range: "+year,
              height: 325,
              width: 550
             };         
        //Define container id to draw the chart     
        var default_barchart = new google.visualization.BarChart(document.getElementById('bar_toner_chart'));  

        //Draw the chart
        default_barchart.draw(data, options); 
        
        // Tell users which segment is selected
        if(segment_bar == "15 Days"){
            document.getElementById("current_toner_segment_div").style.backgroundColor = "blue";
            document.getElementById("current_toner_segment_div").style.color = "white";
        }else if(segment_bar == "30 Days"){
            document.getElementById("current_toner_segment_div").style.backgroundColor = "red";
            document.getElementById("current_toner_segment_div").style.color = "white";
        }else if(segment_bar == "45 Days"){
            document.getElementById("current_toner_segment_div").style.backgroundColor = "orange";
            document.getElementById("current_toner_segment_div").style.color = "black";
        }else if(segment_bar == "60 Days"){
            document.getElementById("current_toner_segment_div").style.backgroundColor = "green";
            document.getElementById("current_toner_segment_div").style.color = "white";
        }else if(segment_bar == "75 Days"){
            document.getElementById("current_toner_segment_div").style.backgroundColor = "purple";
            document.getElementById("current_toner_segment_div").style.color = "white";
        }else if(segment_bar == "90 Days"){
            document.getElementById("current_toner_segment_div").style.backgroundColor = "black";
            document.getElementById("current_toner_segment_div").style.color = "white";
        }else if(segment_bar == "> 90 Days"){
            document.getElementById("current_toner_segment_div").style.backgroundColor = "pink";
            document.getElementById("current_toner_segment_div").style.color = "black";
        }
        
        // Print the selected segment name
        document.getElementById("current_toner_segment").innerHTML = segment_bar;

        // Set the selected default bar chart segment
        default_barchart.setSelection([{row: 0}]); 
        
        function genTableBySeg() {
            var selectedItem = default_barchart.getSelection()[0];

            if (selectedItem) {
                // Get segment name
                var segment_bar = data.getValue(selectedItem.row, 0);

                // Tell users which segment is selected
                if(segment_bar == "15 Days"){
                    document.getElementById("current_toner_segment_div").style.backgroundColor = "blue";
                    document.getElementById("current_toner_segment_div").style.color = "white";
                }else if(segment_bar == "30 Days"){
                    document.getElementById("current_toner_segment_div").style.backgroundColor = "red";
                    document.getElementById("current_toner_segment_div").style.color = "white";
                }else if(segment_bar == "45 Days"){
                    document.getElementById("current_toner_segment_div").style.backgroundColor = "orange";
                    document.getElementById("current_toner_segment_div").style.color = "black";
                }else if(segment_bar == "60 Days"){
                    document.getElementById("current_toner_segment_div").style.backgroundColor = "green";
                    document.getElementById("current_toner_segment_div").style.color = "white";
                }else if(segment_bar == "75 Days"){
                    document.getElementById("current_toner_segment_div").style.backgroundColor = "purple";
                    document.getElementById("current_toner_segment_div").style.color = "white";
                }else if(segment_bar == "90 Days"){
                    document.getElementById("current_toner_segment_div").style.backgroundColor = "black";
                    document.getElementById("current_toner_segment_div").style.color = "white";
                }else if(segment_bar == "> 90 Days"){
                    document.getElementById("current_toner_segment_div").style.backgroundColor = "pink";
                    document.getElementById("current_toner_segment_div").style.color = "black";
                }

                // Save the segment name in hidden input
                document.getElementById("segment_toner_bar").value = segment_bar;

                // Print the selected segment name
                document.getElementById("current_toner_segment").innerHTML = segment_bar; 

                // Launch new request to backend
                xhttp = new XMLHttpRequest();

                xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {   // If request finished and response is ready/ OK
                     // Load the JSON data in the table
                    var data = new google.visualization.DataTable(this.responseText);

                    // Instantiate and draw our chart, passing in some options.
                    var table = new google.visualization.Table(document.getElementById('table_toner_chart'));
                    table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
                }
            }

            // Forward parameters to PHP file
           xhttp.open("GET", "../control/draw_control_toner_cust_bhv_gap_aa.php?action=draw_table&year="+year+"&segname="+segment_bar, true);
           xhttp.send();
           }
       }

        // Enable bar chart event listener 
        google.visualization.events.addListener(default_barchart, 'select', genTableBySeg);
    } 
    
function default_table_toner_cust_bhv_gap_aa(){
        var data = google.visualization.arrayToDataTable([  
        //Column name
        ['cust_id', 'firstname', 'lastname', 'tel', 'pcode', 'min_spt_gap', 'latest_manu', 'dataset_year'],  

        <?php $default_control_toner_cust_bhv_gap_aa->default_table_toner_cust_bhv_gap_aa();?> 
        ]);  

        //Define container id to draw the table     
        var default_table = new google.visualization.Table(document.getElementById('table_toner_chart'));

        //Draw the table
        default_table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});                    
    }    
    
