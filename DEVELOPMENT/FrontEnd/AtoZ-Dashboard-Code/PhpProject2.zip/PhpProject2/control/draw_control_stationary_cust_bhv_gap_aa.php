<?php 
    include("../model/db_connect.php");  
    include("../model/stationary_cust_bhv_gap_aa_model.php");  
    
    // These php code act as controller for draw bar chart
    
    class draw_stationary_cust_bhv_gap_aa_control{
        public static function draw_stationary_cust_bhv_gap_aa(){
            $action = $_GET['action'];
            
            if($action=="draw_table"){
                $year = $_GET['year'];
                $segname = $_GET['segname'];
                draw_stationary_cust_bhv_gap_aa::draw_table_stationary_cust_bhv_gap_aa($segname, $year);
            }
            if($action=="draw_bar_chart"){
                $year = $_GET['year'];
                draw_stationary_cust_bhv_gap_aa::draw_chart_stationary_cust_bhv_gap_aa($year);
            }
            if($action=="draw_table_by_year"){
                $year = $_GET['year'];
                draw_stationary_cust_bhv_gap_aa::draw_table_by_year_stationary_cust_bhv_gap_aa($year);
            }
        }
    }
    
    draw_stationary_cust_bhv_gap_aa_control::draw_stationary_cust_bhv_gap_aa();
?>
