<?php 
    include("../model/db_connect.php");  
    include("../model/ink_cust_bhv_gap_aa_model.php");  
    
    // These php code act as controller for draw bar chart
    
    class draw_ink_cust_bhv_gap_aa_control{
        public static function draw_ink_cust_bhv_gap_aa(){
            $action = $_GET['action'];
            
            if($action=="draw_table"){
                $year = $_GET['year'];
                $segname = $_GET['segname'];
                draw_ink_cust_bhv_gap_aa::draw_table_ink_cust_bhv_gap_aa($segname, $year);
            }
            if($action=="draw_bar_chart"){
                $year = $_GET['year'];
                draw_ink_cust_bhv_gap_aa::draw_chart_ink_cust_bhv_gap_aa($year);
            }
            if($action=="draw_table_by_year"){
                $year = $_GET['year'];
                draw_ink_cust_bhv_gap_aa::draw_table_by_year_ink_cust_bhv_gap_aa($year);
            }
        }
    }
    
    draw_ink_cust_bhv_gap_aa_control::draw_ink_cust_bhv_gap_aa();
?>
