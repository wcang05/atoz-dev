<?php 
include_once("../model/db_connect.php");    
include("../model/def_model_toner_cust_bhv_gap_aa.php");  

// These php code act as controller for default parameters.
  
class default_control_toner_cust_bhv_gap_aa {  
      
        public function list_year_toner_cust_bhv_gap_aa(){  
            default_param_toner_cust_bhv_gap_aa::list_year_toner_cust_bhv_gap_aa();
        }  
        public function latest_year_toner_cust_bhv_gap_aa(){  
            default_param_toner_cust_bhv_gap_aa::latest_year_toner_cust_bhv_gap_aa();
        }  
        public function largest_segment_toner_cust_bhv_gap_aa(){  
            default_param_toner_cust_bhv_gap_aa::largest_segment_toner_cust_bhv_gap_aa();
        } 
        public function default_bar_toner_cust_bhv_gap_aa(){
            default_bar_toner_cust_bhv_gap_aa::default_bar_chart_toner_cust_bhv_gap_aa();
        }
        public function default_table_toner_cust_bhv_gap_aa(){
            default_bar_toner_cust_bhv_gap_aa::default_table_toner_cust_bhv_gap_aa();
        }
    }    
?>
