<?php 
include_once("../model/db_connect.php");    
include("../model/def_model_clean_cust_bhv_gap_aa.php");  

// These php code act as controller for default parameters.
  
class default_control_clean_cust_bhv_gap_aa {  
      
        public function list_year_clean_cust_bhv_gap_aa(){  
            default_param_clean_cust_bhv_gap_aa::list_year_clean_cust_bhv_gap_aa();
        }  
        public function latest_year_clean_cust_bhv_gap_aa(){  
            default_param_clean_cust_bhv_gap_aa::latest_year_clean_cust_bhv_gap_aa();
        }  
        public function largest_segment_clean_cust_bhv_gap_aa(){  
            default_param_clean_cust_bhv_gap_aa::largest_segment_clean_cust_bhv_gap_aa();
        } 
        public function default_bar_clean_cust_bhv_gap_aa(){
            default_bar_clean_cust_bhv_gap_aa::default_bar_chart_clean_cust_bhv_gap_aa();
        }
        public function default_table_clean_cust_bhv_gap_aa(){
            default_bar_clean_cust_bhv_gap_aa::default_table_clean_cust_bhv_gap_aa();
        }
    }    
?>
