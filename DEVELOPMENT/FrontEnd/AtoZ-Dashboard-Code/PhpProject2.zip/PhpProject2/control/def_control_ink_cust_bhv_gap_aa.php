<?php 
include_once("../model/db_connect.php");    
include("../model/def_model_ink_cust_bhv_gap_aa.php");  

// These php code act as controller for default parameters.
  
class default_control_ink_cust_bhv_gap_aa {  
      
        public function list_year_ink_cust_bhv_gap_aa(){  
            default_param_ink_cust_bhv_gap_aa::list_year_ink_cust_bhv_gap_aa();
        }  
        public function latest_year_ink_cust_bhv_gap_aa(){  
            default_param_ink_cust_bhv_gap_aa::latest_year_ink_cust_bhv_gap_aa();
        }  
        public function largest_segment_ink_cust_bhv_gap_aa(){  
            default_param_ink_cust_bhv_gap_aa::largest_segment_ink_cust_bhv_gap_aa();
        } 
        public function default_bar_ink_cust_bhv_gap_aa(){
            default_bar_ink_cust_bhv_gap_aa::default_bar_chart_ink_cust_bhv_gap_aa();
        }
        public function default_table_ink_cust_bhv_gap_aa(){
            default_bar_ink_cust_bhv_gap_aa::default_table_ink_cust_bhv_gap_aa();
        }
    }    
?>
