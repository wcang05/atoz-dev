<?php
include("../model/db_connect.php");  
include("../model/data_model.php");  

// These php code act as controller for data export.

class export_controller{
        public static function export_data(){
            $table = $_POST['table'];
            if(isset($_POST["export"])){  //If "export" parameter is set
                if($table=="all_cust_bhv_gap_aa"){
                    //Accept parameters
                    $year = $_POST['year_all_bar'];
                    $segname = $_POST['segment_all_bar'];
                    data::export_all_cust_bhv_gap_aa($segname, $year);
                }elseif($table=="ink_cust_bhv_gap_aa"){
                    //Accept parameters
                    $year = $_POST['year_ink_bar'];
                    $segname = $_POST['segment_ink_bar'];
                    data::export_ink_cust_bhv_gap_aa($segname, $year);
                }elseif($table=="toner_cust_bhv_gap_aa"){
                    //Accept parameters
                    $year = $_POST['year_toner_bar'];
                    $segname = $_POST['segment_toner_bar'];
                    data::export_toner_cust_bhv_gap_aa($segname, $year);
                }elseif($table=="printer_cust_bhv_gap_aa"){
                    //Accept parameters
                    $year = $_POST['year_printer_bar'];
                    $segname = $_POST['segment_printer_bar'];
                    data::export_printer_cust_bhv_gap_aa($segname, $year);
                }elseif($table=="paper_cust_bhv_gap_aa"){
                    //Accept parameters
                    $year = $_POST['year_paper_bar'];
                    $segname = $_POST['segment_paper_bar'];
                    data::export_paper_cust_bhv_gap_aa($segname, $year);
                }elseif($table=="stationary_cust_bhv_gap_aa"){
                    //Accept parameters
                    $year = $_POST['year_stationary_bar'];
                    $segname = $_POST['segment_stationary_bar'];
                    data::export_stationary_cust_bhv_gap_aa($segname, $year);
                }elseif($table=="clean_cust_bhv_gap_aa"){
                    //Accept parameters
                    $year = $_POST['year_clean_bar'];
                    $segname = $_POST['segment_clean_bar'];
                    data::export_clean_cust_bhv_gap_aa($segname, $year);
                }elseif($table=="brk_cust_bhv_gap_aa"){
                    //Accept parameters
                    $year = $_POST['year_brk_bar'];
                    $segname = $_POST['segment_brk_bar'];
                    data::export_brk_cust_bhv_gap_aa($segname, $year);
                }
            }
        }
    }
    export_controller::export_data();
?>